//
//  llama_cpp.h
//  llama.cpp
//
//  Created by Takashi Bando on 4/11/24.
//

#import <Foundation/Foundation.h>

//! Project version number for llama_cpp.
FOUNDATION_EXPORT double llama_cppVersionNumber;

//! Project version string for llama_cpp.
FOUNDATION_EXPORT const unsigned char llama_cppVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <llama_cpp/PublicHeader.h>


#import <llama_cpp/ggml.h>
#import <llama_cpp/ggml-alloc.h>
#import <llama_cpp/ggml-backend.h>
#import <llama_cpp/llama.h>
